//Exporting as default object  --- using Pascal Casing
export default function Heading() {
  // JSX = JS XML
  // const name = "Saad";
  // if (name)
  return <h1>First Component</h1>;
  //else return <h1>My First Component</h1>;
}
