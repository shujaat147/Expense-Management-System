import React from "react";
interface Props {
  itemsCount: number;
}
const CartCount = ({ itemsCount }: Props) => {
  return (
    <div>
      <h3 className="text-end">
        Item Count <span className="badge bg-secondary">{itemsCount}</span>
      </h3>
    </div>
  );
};

export default CartCount;
