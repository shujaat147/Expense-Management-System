import React, { Children } from "react";
interface Prop {
  color?: "primary" | "secondary" | "warning";
  children: string;
  onPress: () => void;
}

const Button = ({ onPress, color = "primary", children }: Prop) => {
  return (
    <button
      onClick={() => {
        onPress();
      }}
      className={"btn btn-" + color}
    >
      {children}
    </button>
  );
};

export default Button;
