import { ReactNode } from "react";
interface Props {
  children: ReactNode;
  color: string;
}
const Alert = ({ children, color }: Props) => {
  return (
    <div className={"alert alert-" + color + " alert-dismissible"} role="alert">
      {children}
      <button type="button" className="btn-close"></button>
    </div>
  );
};

export default Alert;
